# 🚀 QUICKSTART - Vrijwilligers Matcher Live

## JIJ BENT HIER (5 MINUTEN SETUP)

### ⭐ SNELSTE MANIER: Use GitHub + Vercel (NO CODING!)

**Step 1: Ga naar GitHub**
- https://github.com/new
- Maak repo: `vrijwilligers-matcher`
- Kies "Add a README file"

**Step 2: Upload files**
- Klik "Add file → Upload files"
- Upload: `package.json`, `index-ready-to-deploy.tsx` (hernoem naar `pages/index.tsx`), `.env.example`

**Step 3: Deploy op Vercel (1 klik)**
- Ga https://vercel.com
- Klik "New Project"
- Select je GitHub repo
- Klik "Import"
- Add env vars (zie hieronder)
- Klik "Deploy"

**DONE! 🎉**
Je app is live op: https://jouw-app.vercel.app

---

### 🛠️ LOKAAL TESTEN (Voor developers)

```bash
# 1. Clone of download de files
git clone https://github.com/YOURNAME/vrijwilligers-matcher
cd vrijwilligers-matcher

# 2. Installeer
npm install

# 3. Maak .env.local (kun je skippen, dummy data werkt)
# NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
# NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbG...

# 4. Run
npm run dev

# 5. Open http://localhost:3000
```

---

## 📦 BESTANDEN DIE JE NODIG HEBT

```
projects/
├── package.json                  # Dependencies
├── pages/
│   └── index.tsx                # De echte app (copy van index-ready-to-deploy.tsx)
├── public/
│   └── favicon.ico              # (optional)
├── .env.example                 # (optional)
└── next.config.js              # (standaard Next.js)
```

### package.json
```json
{
  "name": "vrijwilligers-matcher",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "@types/node": "^20",
    "@types/react": "^18",
    "typescript": "^5"
  }
}
```

### .env.example
```
NEXT_PUBLIC_SUPABASE_URL=your_url_here
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_key_here
```

---

## 🎯 VERCEL ENV VARS (kopier deze na deploy!)

In Vercel Dashboard:
1. Ga "Settings → Environment Variables"
2. Add:
   - Key: `NEXT_PUBLIC_SUPABASE_URL` → Value: `https://xxxxx.supabase.co`
   - Key: `NEXT_PUBLIC_SUPABASE_ANON_KEY` → Value: `eyJhbG...`

*Pas later als je Supabase integreert. Nu werkt het met mock data!*

---

## 🔥 FEATURES (READY NOW)

✅ Swipe matching (Tinder-style)
✅ Volunteer & Association profiles
✅ Beautiful UI (Tailwind)
✅ Responsive mobile + desktop
✅ Match history
✅ NO backend needed (works locally)

## 🚀 NEXT PHASE (LATER)

🔜 Supabase database integration
🔜 User authentication
🔜 Real profile upload
🔜 Notification system
🔜 Multi-municipality support

---

## 🆘 COMMON ISSUES

**"npm install fails"**
- Check: Node.js 16+ installed? (`node -v`)
- Try: `npm cache clean --force && npm install`

**"http://localhost:3000 blank"**
- Check terminal: Errors?
- Try: `npm run dev` again
- Check: Are you on http://localhost:3000 (not https)?

**"Vercel deploy fails"**
- Check: GitHub push was successful?
- Check: package.json exists?
- Try: Manual deploy via `npm install -g vercel && vercel`

**"Can't find pages/index.tsx"**
- Check: Did you create `pages/` folder?
- Check: Did you rename the file correctly?
- Tip: Create new file in Vercel with content

---

## 📱 TESTING CHECKLIST

- [ ] Can select "Vrijwilliger" or "Vereniging"?
- [ ] Swipe buttons work (❤️ and 👎)?
- [ ] Match count increases?
- [ ] Click "Matches" shows your matches?
- [ ] Mobile looks good?
- [ ] Can go back and switch types?

---

## 🎁 NEXT STEP: ADD DATABASE

Ready to make it REAL? Follow: `DEPLOYMENT.md`

---

## 🤝 QUESTIONS?

Discord: [Link to your server]
Email: [Your email]
Docs: https://nextjs.org/docs

---

**Version 1.0.0 - Ready for Alken MVP!**
Built with ❤️ for volunteers everywhere
