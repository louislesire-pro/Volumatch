// pages/index.tsx - Paste dit in je Next.js project
'use client';

import React, { useState, useEffect } from 'react';
import Head from 'next/head';

// Mock data (vervang met Supabase calls in production)
const mockVolunteers = [
  { id: '1', name: 'Jan', age: 67, skills: ['Tappen', 'Koken'], availability: 'Weekends', interests: 'Jeugd', bio: 'Gepensioneerde die graag wil helpen', image: '👨‍🦳' },
  { id: '2', name: 'Marie', age: 45, skills: ['Administratie', 'Organiseren'], availability: 'Avonden', interests: 'Sociale werking', bio: 'HR-specialist met ervaring', image: '👩‍💼' },
  { id: '3', name: 'Thomas', age: 28, skills: ['Sport', 'Trainen'], availability: 'Flexibel', interests: 'Sport', bio: 'Ex-voetballer, wil jeugd begeleiden', image: '👨' },
  { id: '4', name: 'Sofia', age: 52, skills: ['Tuinieren', 'Repareren'], availability: 'Dags', interests: 'Onderhoud', bio: 'Groenkundig met leidinggevend ervaring', image: '👩' },
];

const mockAssociations = [
  { id: '101', name: 'Chiro Alken', type: 'Jeugd', needs: 'Tappers voor fuif', bio: 'Grootste jeugdbeweging van Alken', location: 'Alken', image: '⛺' },
  { id: '102', name: 'VV Alken', type: 'Sport', needs: 'Trainer assistent U10', bio: 'Voetbalvereniging met 200+ leden', location: 'Alken', image: '⚽' },
  { id: '103', name: 'Woonzorg Sint-Jozef', type: 'Zorg', needs: 'Bezoekers voor bewoners', bio: 'Rusthuis met 80 bewoners', location: 'Alken', image: '🏥' },
  { id: '104', name: 'Buurtfeest organisatie', type: 'Cultuur', needs: 'Organiseerders & helpers', bio: 'Organiseert jaarlijkse buurtfeesten', location: 'Alken', image: '🎉' },
];

interface SwipeCardProps {
  item: typeof mockVolunteers[0] | typeof mockAssociations[0];
  isVolunteer: boolean;
  onSwipe: (liked: boolean) => void;
}

interface MatchListProps {
  matches: Array<{ volunteer: string; association: string; date: string }>;
}

function SwipeCard({ item, isVolunteer, onSwipe }: SwipeCardProps) {
  return (
    <div className="bg-white rounded-2xl shadow-2xl overflow-hidden max-w-sm w-full mx-auto">
      <div className="h-72 bg-gradient-to-br from-purple-400 via-pink-400 to-red-400 flex items-center justify-center text-8xl relative group overflow-hidden">
        <div className="text-8xl">{item.image}</div>
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300"></div>
      </div>
      
      <div className="p-8">
        <div className="flex items-baseline gap-2 mb-3">
          <h2 className="text-3xl font-black text-gray-900">{item.name}</h2>
          {'age' in item && <span className="text-gray-500 text-lg">{item.age}</span>}
        </div>
        
        <p className="text-gray-600 mb-6 text-base leading-relaxed">{item.bio}</p>

        {isVolunteer ? (
          <>
            <div className="space-y-2 mb-6 bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg">
              <p className="text-sm font-bold text-purple-700">
                📍 {item.type}
              </p>
              <p className="text-sm text-gray-700">
                Zoeken: <span className="font-semibold text-red-600">{item.needs}</span>
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="space-y-2 mb-6 bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
              <p className="text-sm">
                <span className="font-bold text-blue-700">💪 Skills:</span> {item.skills?.join(', ')}
              </p>
              <p className="text-sm">
                <span className="font-bold text-blue-700">🕐 Beschikbaar:</span> {item.availability}
              </p>
              <p className="text-sm">
                <span className="font-bold text-blue-700">❤️ Interesses:</span> {item.interests}
              </p>
            </div>
          </>
        )}

        <div className="flex gap-6 justify-center pt-6 border-t border-gray-200">
          <button
            onClick={() => onSwipe(false)}
            className="text-5xl cursor-pointer hover:scale-125 hover:-rotate-12 transition-all duration-200 transform"
            title="Niet interessant"
          >
            👎
          </button>
          <button
            onClick={() => onSwipe(true)}
            className="text-5xl cursor-pointer hover:scale-125 hover:rotate-12 transition-all duration-200 transform"
            title="Perfect match!"
          >
            ❤️
          </button>
        </div>
      </div>
    </div>
  );
}

function MatchList({ matches }: MatchListProps) {
  if (matches.length === 0) {
    return (
      <div className="text-center py-16 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl">
        <div className="text-6xl mb-4">🎯</div>
        <p className="text-xl text-gray-600">
          Nog geen matches! Begin met swipen en maak magic ✨
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <h3 className="text-2xl font-bold text-gray-900 mb-6">Je matches 🎉</h3>
      {matches.map((match, idx) => (
        <div
          key={idx}
          className="bg-white border-l-4 border-purple-600 rounded-lg p-5 shadow-md hover:shadow-lg transition-shadow"
        >
          <p className="font-bold text-lg text-gray-900">
            {match.volunteer} <span className="text-green-500">✓</span> {match.association}
          </p>
          <p className="text-sm text-gray-500 mt-1">{match.date}</p>
        </div>
      ))}
    </div>
  );
}

export default function Home() {
  const [userType, setUserType] = useState<'volunteer' | 'association' | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [matches, setMatches] = useState<Array<{ volunteer: string; association: string; date: string }>>([]);
  const [view, setView] = useState<'choose' | 'swipe' | 'matches'>('choose');

  const volunteers = mockVolunteers;
  const associations = mockAssociations;

  const handleSwipe = (liked: boolean) => {
    if (!userType) return;

    const items = userType === 'volunteer' ? associations : volunteers;
    const currentItem = items[currentIdx];
    const otherItem = userType === 'volunteer' ? volunteers[0] : associations[0];

    if (liked) {
      const match = {
        volunteer: userType === 'volunteer' ? otherItem.name : currentItem.name,
        association: userType === 'volunteer' ? currentItem.name : otherItem.name,
        date: new Date().toLocaleDateString('nl-BE'),
      };
      setMatches([...matches, match]);
    }

    if (currentIdx < items.length - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      alert('Geen meer ' + (userType === 'volunteer' ? 'verenigingen' : 'vrijwilligers') + '!');
      setCurrentIdx(0);
    }
  };

  if (view === 'choose' || !userType) {
    return (
      <>
        <Head>
          <title>❤️ Vrijwilligers Matcher - Tinder voor goed werk</title>
          <meta name="viewport" content="width=device-width, initial-scale=1" />
        </Head>

        <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 flex items-center justify-center p-4">
          <div className="text-center">
            <h1 className="text-6xl font-black text-white mb-3 drop-shadow-lg">
              ❤️ Vrijwilligers Matcher
            </h1>
            <p className="text-2xl text-white/90 mb-12 drop-shadow font-semibold">
              Tinder voor goed vrijwilligerswerk
            </p>
            
            <div className="space-y-4 max-w-sm mx-auto">
              <button
                onClick={() => {
                  setUserType('volunteer');
                  setView('swipe');
                }}
                className="w-full bg-white text-purple-600 py-4 rounded-xl font-bold text-lg hover:scale-105 transition transform shadow-lg hover:shadow-2xl"
              >
                👤 Ik ben vrijwilliger
              </button>
              <button
                onClick={() => {
                  setUserType('association');
                  setView('swipe');
                }}
                className="w-full bg-white text-pink-600 py-4 rounded-xl font-bold text-lg hover:scale-105 transition transform shadow-lg hover:shadow-2xl"
              >
                🏢 Ik ben een vereniging
              </button>
            </div>

            <div className="mt-12 text-white/80 text-sm">
              <p>💡 Swipe rechts (❤️) voor matches, links (👎) om door te gaan</p>
            </div>
          </div>
        </div>
      </>
    );
  }

  const items = userType === 'volunteer' ? associations : volunteers;
  const currentItem = items[currentIdx];

  return (
    <>
      <Head>
        <title>
          {view === 'swipe' ? 'Swipe' : 'Matches'} | Vrijwilligers Matcher
        </title>
      </Head>

      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-red-50">
        {/* Header */}
        <header className="bg-white/80 backdrop-blur-sm border-b border-purple-200 sticky top-0 z-50 shadow-sm">
          <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setUserType(null);
                  setView('choose');
                }}
                className="text-2xl hover:scale-110 transition"
              >
                ←
              </button>
              <h1 className="text-2xl font-black bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                ❤️ Matcher
              </h1>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setView('swipe')}
                className={`px-5 py-2 rounded-lg font-bold transition transform ${
                  view === 'swipe'
                    ? 'bg-purple-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Swipe
              </button>
              <button
                onClick={() => setView('matches')}
                className={`px-5 py-2 rounded-lg font-bold transition transform ${
                  view === 'matches'
                    ? 'bg-purple-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Matches ({matches.length})
              </button>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="max-w-4xl mx-auto px-4 py-12">
          {view === 'swipe' && currentItem && (
            <SwipeCard
              item={currentItem}
              isVolunteer={userType === 'volunteer'}
              onSwipe={handleSwipe}
            />
          )}

          {view === 'matches' && <MatchList matches={matches} />}
        </main>
      </div>
    </>
  );
}
