# 🚀 Deployment Guide - Vrijwilligers Matcher

## SNELSTE WEG (3 stappen, 10 minuten)

### Stap 1: Maak Supabase account
1. Ga naar https://supabase.com
2. Klik "Sign up with GitHub" (makkelijker)
3. Maak een nieuwe project aan (kies regio EU voor GDPR ✓)
4. Noteer: **Project URL** en **Anon Key** (zie Settings → API)

### Stap 2: Setup database
In Supabase:
1. Ga naar SQL Editor
2. Klik "+ New Query"
3. Copy-paste deze code:

```sql
CREATE TABLE IF NOT EXISTS volunteers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  name VARCHAR(255),
  age INTEGER,
  skills TEXT[],
  availability VARCHAR(255),
  interests VARCHAR(255),
  bio TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  FOREIGN KEY (user_id) REFERENCES auth.users(id)
);

CREATE TABLE IF NOT EXISTS associations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  name VARCHAR(255),
  type VARCHAR(255),
  needs TEXT,
  bio TEXT,
  location VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW(),
  FOREIGN KEY (user_id) REFERENCES auth.users(id)
);

CREATE TABLE IF NOT EXISTS matches (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  volunteer_id UUID REFERENCES volunteers(id) ON DELETE CASCADE,
  association_id UUID REFERENCES associations(id) ON DELETE CASCADE,
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(volunteer_id, association_id)
);

CREATE TABLE IF NOT EXISTS swipes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  target_id UUID NOT NULL,
  liked BOOLEAN,
  target_type VARCHAR(20),
  created_at TIMESTAMP DEFAULT NOW()
);
```

4. Klik "Run"

### Stap 3: Deploy op Vercel

**OPTIE A: Met GitHub (AANBEVOLEN)**
```bash
# 1. Push je code naar GitHub
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/vrijwilligers-matcher.git
git branch -M main
git push -u origin main

# 2. Ga naar https://vercel.com
# 3. Klik "New Project"
# 4. Import je GitHub repo
# 5. Add Environment Variables:
#    - NEXT_PUBLIC_SUPABASE_URL
#    - NEXT_PUBLIC_SUPABASE_ANON_KEY
# 6. Klik "Deploy"
```

**OPTIE B: Direct (zonder GitHub)**
```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Deploy
vercel

# 3. Add environment variables when prompted
```

---

## LOKAAL TESTEN (Voordien deployen)

```bash
# 1. Installeer dependencies
npm install

# 2. Maak .env.local aan
# Copy-paste (met JE Supabase keys!):
NEXT_PUBLIC_SUPABASE_URL=https://XXXXX.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbG...
NEXTAUTH_SECRET=supersecretkey123

# 3. Run dev server
npm run dev

# 4. Open http://localhost:3000
```

---

## BUILD & DEPLOY

```bash
# Production build
npm run build
npm run start

# Of deploy direct naar Vercel
npm run deploy
```

---

## VOLGENDE STAPPEN

✅ **Live & werkend?** Dan:
1. Maak test account
2. Voeg profielen toe
3. Test swipen & matchen
4. Share link: `https://jouw-app.vercel.app`

---

## COMMON ISSUES

**"Supabase key not working"**
- Check: je hebt NEXT_PUBLIC_ prefix? ✓
- Check: je copypaste-de de hele key? (geen spaties)

**"Build failed"**
- Heb je `npm install` gedaan? Ja?
- Check de error log in Vercel dashboard

**"Login werkt niet"**
- In Supabase: Auth → Providers → Email → Enable

**"Database errors"**
- Voerde je SQL correct uit in Supabase? ✓
- Geen typos in table names?

---

## SCALING (Later)

Als je >100 users hebt:
- Upgrade Supabase plan (gratis tier → $25/mo)
- Vercel auto-scales (geen setup nodig)
- Add email notifications (SendGrid API)

---

## PROMO & UITROL

**Fase 1: Alken**
- Invite vrijwilligers
- Invite verenigingen
- Track matches & feedback

**Fase 2: Andere gemeentes**
- Duplicate project in Supabase
- Add municipality selector in UI
- Separate databases per gemeente

**Fase 3: API & integratie**
- Connect met gemeente-portals
- Add calendar sync
- Impact dashboard

---

Vragen? Check:
- Supabase docs: https://supabase.com/docs
- Vercel docs: https://vercel.com/docs
- Next.js docs: https://nextjs.org/docs
